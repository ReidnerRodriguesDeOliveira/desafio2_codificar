<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class gastosController extends Controller
{
    public function showapi()
    {
        $response_xml_data = file_get_contents("http://dadosabertos.almg.gov.br/ws/deputados/em_exercicio");
        if($response_xml_data)
        {
            echo "read";
        }

        $data = simplexml_load_string($response_xml_data);

        return response()->$data;
}
}
